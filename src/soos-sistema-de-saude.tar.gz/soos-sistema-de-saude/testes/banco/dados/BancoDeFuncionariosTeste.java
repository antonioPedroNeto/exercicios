package banco.dados;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.Month;

import org.junit.Before;
import org.junit.Test;

import enumeration.Cargo;
import exceptions.FuncionarioInvalidoException;
import funcionario.Funcionario;


public class BancoDeFuncionariosTeste {

	BancoDeFuncionarios dataBase;
	Funcionario funcionarioDeTeste;
	
	@Before
	public void setUp(){
		dataBase = new BancoDeFuncionarios();
		funcionarioDeTeste = new Funcionario("Pedro", "32016001", "20163201", Cargo.TECNICO_ADMINISTRATIVO, LocalDate.of(1996, Month.SEPTEMBER, 03));
	}
	

	@Test
	public void testAdicionaFuncionario() {
		assertEquals(true,dataBase.adicionaFuncionario(funcionarioDeTeste));
		assertEquals(false,dataBase.adicionaFuncionario(funcionarioDeTeste));
	}

	@Test
	public void testRemoveFuncionario() {
		assertEquals(false, dataBase.removeFuncionario("32016001"));//usuario ainda nao cadastrado
		dataBase.adicionaFuncionario(funcionarioDeTeste);
		assertEquals(1, dataBase.getQuantidadeDeFuncionarios());
		assertEquals(true, dataBase.removeFuncionario("32016001"));
		assertEquals(0, dataBase.getQuantidadeDeFuncionarios());

	}

	@Test
	public void testBuscaFuncionario() {
		dataBase.adicionaFuncionario(funcionarioDeTeste);
		assertEquals(false, dataBase.buscaFuncionario("0000000"));
		assertEquals(true, dataBase.buscaFuncionario("32016001"));
	}

	@Test
	public void testGetFuncionario() {
		dataBase.adicionaFuncionario(funcionarioDeTeste);
		try {
			assertEquals(funcionarioDeTeste, dataBase.getFuncionario("32016001"));
			dataBase.getFuncionario("000000");
		} catch (FuncionarioInvalidoException e) {
			assertEquals("Funcionario nao existe", e.getMessage());
		}
	}

	@Test
	public void testGetQuantidadeDeFuncionarios() {
		assertEquals(0, dataBase.getQuantidadeDeFuncionarios());
		dataBase.adicionaFuncionario(funcionarioDeTeste);
		assertEquals(1, dataBase.getQuantidadeDeFuncionarios());
		dataBase.removeFuncionario("32016001");
		assertEquals(0, dataBase.getQuantidadeDeFuncionarios());
		
	}

}
