package sistema.controller;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.Month;

import org.junit.Before;
import org.junit.Test;

import banco.dados.BancoDeFuncionarios;
import enumeration.Cargo;
import exceptions.FuncionarioInvalidoException;
import exceptions.SoosException;
import exceptions.StatusDeSistemaException;
import exceptions.StringInvalidaException;
import sistema.controller.ControllerAcessos;

public class ControllerAcessosTest {
	ControllerAcessos controller;
	ControllerAcessos controllerInvalido;
	ControllerAcessos controllerTest;
	ControllerAcessos controllerLogin;
	String matriculaControllerLogin;
	String senhaControllerLogin;
	
	@Before
	public void setUp(){
		controllerInvalido = new ControllerAcessos();
		controllerTest = new ControllerAcessos();
		controllerLogin = new ControllerAcessos();
	}
	
	@Test
	public void testCadastraFuncionario(){
		// testa o metodo em si e suas permissoes
		try {
			String matriculaControllerTest = controllerTest.liberaSistema("c041ebf8");
			String senhaControllerTest = LocalDate.now().getYear() + matriculaControllerTest.substring(0, 4);
			
			assertEquals(true, controllerTest.cadastraFuncionario("Pedro", Cargo.TECNICO_ADMINISTRATIVO, LocalDate.of(1996, Month.SEPTEMBER, 03)));
			System.out.println(controllerTest.buscaFuncionario("32016001"));
			
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}
}
