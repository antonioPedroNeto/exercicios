package factorys;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.Month;

import org.junit.Before;
import org.junit.Test;

import enumeration.Cargo;
import funcionario.Funcionario;

public class FactoryDeFuncionariosTest{

	
	
	@Before
	public void setUp(){
		
	}
	
	@Test
	public void testCriaFuncionarios() {
		Funcionario f1 = new Funcionario("Pedro", "32016001", "20163201", Cargo.TECNICO_ADMINISTRATIVO, LocalDate.of(1996, Month.SEPTEMBER, 03));
		Funcionario f2 = new Funcionario("Pedro", "32016002", "20163201", Cargo.TECNICO_ADMINISTRATIVO, LocalDate.of(1996, Month.SEPTEMBER, 03));
		Funcionario f3 = new Funcionario("Pedro", "32016003", "20163201", Cargo.TECNICO_ADMINISTRATIVO, LocalDate.of(1996, Month.SEPTEMBER, 03)); 
		Funcionario f4 = new Funcionario("Pedro", "22016004", "20162201", Cargo.MEDICO, LocalDate.of(1996, Month.SEPTEMBER, 03));
		Funcionario f5 = new Funcionario("Pedro", "12016005", "20161201", Cargo.DIRETOR_GERAL, LocalDate.of(1996, Month.SEPTEMBER, 03));
		
		
		
		FactoryDeFuncionarios fac = new FactoryDeFuncionarios();
		assertEquals(f1, fac.criaFuncionario("Pedro", Cargo.TECNICO_ADMINISTRATIVO, LocalDate.of(1996, Month.SEPTEMBER, 03)));
		assertEquals(f2, fac.criaFuncionario("Pedro", Cargo.TECNICO_ADMINISTRATIVO, LocalDate.of(1996, Month.SEPTEMBER, 03)));
		assertEquals(f3, fac.criaFuncionario("Pedro", Cargo.TECNICO_ADMINISTRATIVO, LocalDate.of(1996, Month.SEPTEMBER, 03)));
		assertEquals(f4, fac.criaFuncionario("Pedro", Cargo.MEDICO, LocalDate.of(1996, Month.SEPTEMBER, 03)));
		assertEquals(f5, fac.criaFuncionario("Pedro", Cargo.DIRETOR_GERAL, LocalDate.of(1996, Month.SEPTEMBER, 03)));

	}

}
