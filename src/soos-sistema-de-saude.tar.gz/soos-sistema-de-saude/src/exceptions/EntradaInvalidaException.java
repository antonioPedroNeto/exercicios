package exceptions;

/**
 * Classe que trata Exceptions causadas por dados de entrada invalidos.
 * 
 * @author davi laerte
 *
 */
public class EntradaInvalidaException extends SoosException {

	private static final long serialVersionUID = 1L;

	public EntradaInvalidaException() {
		super("a entrada eh invalida");
	}

	public EntradaInvalidaException(String message) {
		super(message);
	}

}// fim classe.
