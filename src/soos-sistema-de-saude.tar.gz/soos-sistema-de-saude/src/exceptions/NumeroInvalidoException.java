package exceptions;


/**
 * Classe que trata Exceptions causadas por numeros invalidos.
 * 
 * @author davi laerte
 *
 */
public class NumeroInvalidoException extends EntradaInvalidaException {
	
	private static final long serialVersionUID = 1L;
	
	public NumeroInvalidoException(){
		super("o numero eh invalido");
	}
	
	public NumeroInvalidoException(String message){
		super(message);
	}

}//fim classe.
