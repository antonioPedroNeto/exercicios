package exceptions;

/**
 * 
 * @author Lucas Silva
 *
 */
public class FuncionarioInvalidoException extends SoosException {
	private static final long serialVersionUID = 1L;

	public FuncionarioInvalidoException(){
		super("Funcionario invalido.");
	}
	
	public FuncionarioInvalidoException(String mensagem){
		super(mensagem);
	}
}
