package exceptions;


/**
 * Classe que trata Exceptions causadas por Strings invalidos.
 * 
 * @author davi laerte
 *
 */
public class StringInvalidaException extends EntradaInvalidaException {
	
	private static final long serialVersionUID = 1L;
	
	public StringInvalidaException(){
		super("O valor passado nao pode ser nulo ou vazio.");
	}
	
	public StringInvalidaException(String message){
		super(message);
	}

}//fim classe.
