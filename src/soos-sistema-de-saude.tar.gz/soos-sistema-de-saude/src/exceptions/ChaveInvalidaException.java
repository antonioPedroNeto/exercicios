package exceptions;

/**
 * 
 * @author Lucas Silva
 *
 */
public class ChaveInvalidaException extends StringInvalidaException {

	private static final long serialVersionUID = 1L;

	public ChaveInvalidaException(){
		super("A chave informada eh invalida.");
	}
	
	public ChaveInvalidaException(String mensagem){
		super(mensagem);
	}
}
