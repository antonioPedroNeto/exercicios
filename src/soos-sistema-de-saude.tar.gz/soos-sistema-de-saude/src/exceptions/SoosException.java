package exceptions;

/**
 * Classe que trata Exceptions do Sistema Orientado a Objetos para a Saúde.
 * 
 * @author davi laerte
 *
 */
public class SoosException extends Exception {

	private static final long serialVersionUID = 1L;

	public SoosException() {
		super("O dado eh invalido");
	}

	public SoosException(String message) {
		super(message);
	}

}// fim classe.
