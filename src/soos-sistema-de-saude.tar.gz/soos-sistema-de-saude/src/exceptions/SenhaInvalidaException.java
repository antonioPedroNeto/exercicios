package exceptions;

/**
 * 
 * @author Lucas Silva
 *
 */
public class SenhaInvalidaException extends StringInvalidaException {

	private static final long serialVersionUID = 1L;

	public SenhaInvalidaException(){
		super("A senha informada eh invalida.");
	}
	
	public SenhaInvalidaException(String mensagem){
		super(mensagem);
	}
}
