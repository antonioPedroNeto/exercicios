package exceptions;

public class StatusDeSistemaException extends SoosException {
	private static final long serialVersionUID = 1L;

	public StatusDeSistemaException(){
		super("O sistema ja tem esse estado.");
	}
	
	public StatusDeSistemaException(String mensagem){
		super(mensagem);
	}
}
