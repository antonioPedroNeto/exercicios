package exceptions;

public class PermissaoInsuficienteException extends SoosException {
	private static final long serialVersionUID = 1L;

	public PermissaoInsuficienteException(){
		super("O funcionario logado nao tem permissao para acessar esta funcao.");
	}
	
	public PermissaoInsuficienteException(String mensagem){
		super(mensagem);
	}
}
