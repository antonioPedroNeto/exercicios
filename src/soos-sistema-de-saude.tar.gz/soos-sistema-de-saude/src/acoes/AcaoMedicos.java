package acoes;

import java.time.LocalDate;

import enumeration.Cargo;
import enumeration.TipoSanguineo;
import exceptions.SenhaInvalidaException;
import factorys.FactoryDeFuncionarios;
import factorys.FactoryDePacientes;
import factorys.FactoryProntuario;
import funcionario.Funcionario;
import pacientes.paciente.Paciente;

public class AcaoMedicos implements AcoesFuncionarios{
	
	FactoryDeFuncionarios factoryFuncionarios;
	FactoryDePacientes factoryDePacientes;
	
	
	public AcaoMedicos(){
		this.factoryFuncionarios = new FactoryDeFuncionarios();
		this.factoryDePacientes = new FactoryDePacientes();
	}
	
	/**
	 * Metodo que gera um funcionario
	 * @param nome - nome do funcionario
	 * @param cargo - cargo do funcionario
	 * @param dataNascimento - data de nascimento do funcionario
	 * @return retorna um funcionario
	 */
	public Funcionario cadastraFuncionario(String nome, Cargo cargo, LocalDate dataNascimento) throws Exception{
		throw new Exception("Voce nao tem acesso suficiente para cadastrar funcionarios");
	}//fecha geraFuncionario
	
	/**
	 * Metodo que altera o nome do funcionario
	 * @param funcionario - funcionario para alterar o nome
	 * @param nome - novo nome do funcionario
	 * @return retorna true para alterado com sucesso ou false para nao alterado.
	 */
	public boolean alteraNome(Funcionario funcionario, String nome){
		funcionario.setNome(nome);
		return true;
		
	}//fecha alteraNome
	/**
	 * Metodo que altera a senha de um funcionario
	 * @param funcionario - funcionario para altera a senha
	 * @param senha - nova senha do funcionario
	 * @param senhaAntiga - senha antiga do funcionario
	 * @return - retorna true para senha trocada com sucesso ou false para nao trocado
	 * @throws SenhaInvalidaException
	 */
	public boolean alteraSenha(Funcionario funcionario, String senha, String senhaAntiga) throws SenhaInvalidaException{
	
		return funcionario.setSenha(senhaAntiga, senha);

	}//fecha alteraSenha

	@Override
	public Paciente cadastraPacientes(String nome, LocalDate dataDeNascimento, double peso, TipoSanguineo tipoSanguineo,
			String sexoBiologico, String genero) {
		S
		return factoryDePacientes.cadastraPaciente(nome, dataDeNascimento, peso, sexoBiologico, genero, tipoSanguineo);
		
	}
	
	
	
}