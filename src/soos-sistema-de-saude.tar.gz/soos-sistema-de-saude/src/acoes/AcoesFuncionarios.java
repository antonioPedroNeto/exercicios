package acoes;

import java.time.LocalDate;

import enumeration.Cargo;
import enumeration.TipoSanguineo;
import exceptions.SenhaInvalidaException;
import factorys.FactoryDeFuncionarios;
import factorys.FactoryProntuario;
import funcionario.Funcionario;
import pacientes.paciente.Paciente;


public interface AcoesFuncionarios {
	
	
	/**
	 * Metodo que gera um funcionario
	 * @param nome - nome do funcionario
	 * @param cargo - cargo do funcionario
	 * @param dataNascimento - data de nascimento do funcionario
	 * @return retorna um funcionario
	 */
	public Funcionario cadastraFuncionario(String nome, Cargo cargo, LocalDate dataNascimento) throws Exception;
	
	/**
	 * Metodo que altera o nome do funcionario
	 * @param funcionario - funcionario para alterar o nome
	 * @param nome - novo nome do funcionario
	 * @return retorna true para alterado com sucesso ou false para nao alterado.
	 */
	public boolean alteraNome(Funcionario funcionario, String nome);
	
	
	/**
	 * Metodo que altera a senha de um funcionario
	 * @param funcionario - funcionario para altera a senha
	 * @param senha - nova senha do funcionario
	 * @param senhaAntiga - senha antiga do funcionario
	 * @return - retorna true para senha trocada com sucesso ou false para nao trocado
	 * @throws SenhaInvalidaException
	 */
	public boolean alteraSenha(Funcionario funcionario, String senha, String senhaAntiga) throws SenhaInvalidaException;
	

	public Paciente cadastraPacientes(String nome,LocalDate dataDeNascimento,double peso, TipoSanguineo tipoSanguineo, String sexoBiológico,String genero);
	
}
