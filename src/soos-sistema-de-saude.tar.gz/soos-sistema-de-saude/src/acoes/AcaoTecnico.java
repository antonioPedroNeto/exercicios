package acoes;

import java.time.LocalDate;

import enumeration.Cargo;
import enumeration.TipoSanguineo;
import exceptions.SenhaInvalidaException;
import factorys.FactoryDeFuncionarios;
import factorys.FactoryDePacientes;
import funcionario.Funcionario;
import pacientes.paciente.Paciente;

public class AcaoTecnico implements AcoesFuncionarios{

	FactoryDeFuncionarios factoryFuncionarios;
	FactoryDePacientes factoryDePacientes;
	
	
	public AcaoTecnico() {
		this.factoryFuncionarios = new FactoryDeFuncionarios();
		this.factoryDePacientes = new FactoryDePacientes();
	}
	
	@Override
	public Funcionario cadastraFuncionario(String nome, Cargo cargo, LocalDate dataNascimento) throws Exception {
		throw new Exception("Voce nao tem permissao para cadastra novos funcionarios");
	}

	@Override
	public boolean alteraNome(Funcionario funcionario, String nome) {
		return false;
	}

	@Override
	public boolean alteraSenha(Funcionario funcionario, String senha, String senhaAntiga)
			throws SenhaInvalidaException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Paciente cadastraPacientes(String nome, LocalDate dataDeNascimento, double peso, TipoSanguineo tipoSanguineo,
			String sexoBiologico, String genero) {
		return factoryDePacientes.cadastraPaciente(nome, dataDeNascimento, peso, sexoBiologico, genero, tipoSanguineo);
		
	}
}
