package medicamentos;

public class MedicamentoReferencia implements IMedicamento{

	
	public MedicamentoReferencia() {
		
		
	}

	@Override
	public double calculaDesconto(double preco) {
		return preco;//ate o momento o medicamento de referencia nao possui um desconto
	}
		
	
	
	
}//fecha class
