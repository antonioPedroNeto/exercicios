package medicamentos;

public interface IMedicamento {

	/**
	 * Metodo que pega o desconto
	 * @return retorna o preco com o respectivo desconto
	 */
	public double calculaDesconto(double preco);
	
	
}//fecha class
