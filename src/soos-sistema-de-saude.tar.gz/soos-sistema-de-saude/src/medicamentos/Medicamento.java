package medicamentos;

import java.util.HashSet;
import java.util.Set;

import enumeration.Categoria;

public class Medicamento {
	
	private IMedicamento medicamento;//<composicao polimorfica
	
	private final String GENERICO = "generico";
	private String nome;
	private double preco;
	private int quantidade;
	private Set<Categoria> categorias;
	
	private Medicamento(String nome, double preco, int quantidade, HashSet<Categoria> categorias, String tipo){
		this.nome = nome;
		this.preco = preco;
		this.quantidade = quantidade;
		this.categorias = categorias;
		
		if(tipo.equalsIgnoreCase(GENERICO)){
			this.medicamento = new MedicamentoGenerico();
		}else{
			this.medicamento = new MedicamentoReferencia();
		}
		
	}
	
	/**
	 * Metodo que retorna o nome do remedio
	 * @return retorna o nome
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * Metodo que muda o nome do remedio
	 * @param nome - novo nome do remedio
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}


	/**
	 * Metodo que pega o preco do remedio
	 * @return retorna o preco do remedio
	 */
	public double getPreco() {
		return preco;
	}

	
	public void setPreco(double preco) {
		this.preco = preco;
	}


	public int getQuantidade() {
		return quantidade;
	}


	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}


	public Set<Categoria> getCategorias() {
		return categorias;
	}


	public void setCategorias(Set<Categoria> categorias) {
		this.categorias = categorias;
	}
	
	/**
	 * Metodo que calcula o desconto do medicamento
	 * @return retorna o preco com desconto tipo de medicamento
	 */
	public double calculaDesconto(){
		return medicamento.calculaDesconto(this.preco);//<<chamada polimorfica
	}
	

}
