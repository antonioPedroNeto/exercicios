package medicamentos;

public class MedicamentoGenerico implements IMedicamento{

	
	private final double DESCONTO;

	
	public MedicamentoGenerico() {

		this.DESCONTO = 0.6;
		
	}


	@Override
	public double calculaDesconto(double preco) {
		return preco*DESCONTO;
	}
	
	
}//fecha class
