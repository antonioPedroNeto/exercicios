package banco.dados;

import java.util.HashMap;
import java.util.Map;

import exceptions.FuncionarioInvalidoException;
import funcionario.Funcionario;

public class BancoDeFuncionarios {
	
	
	private Map<String, Funcionario> equipeFuncionarios;
	
	public BancoDeFuncionarios(){
		equipeFuncionarios = new HashMap<String, Funcionario>();
	}
	
	/**
	 * Metodo que adiciona um funcionario
	 * @param funcionario - um funcionario
	 * @return retorna true para adicionado com sucesso ou false para nao adicionado
	 */
	public boolean adicionaFuncionario(Funcionario funcionario){		
		
		if(buscaFuncionario(funcionario.getMatricula())){
			return false;
		}//fecha if
		
		equipeFuncionarios.put(funcionario.getMatricula(), funcionario);
		return true;
	
	}//fecha andicionaFuncionario
	
	
	
	/**
	 * Metodo que remove o funcionario do Banco
	 * @param matricula - matricula do funcionario
	 * @return retorna true para removido com sucesso ou false para nao removido
	 */
	public boolean removeFuncionario(String matricula){
		if(equipeFuncionarios.containsKey(matricula)){
			equipeFuncionarios.remove(matricula);
			return true;
		}//fecha if
		return false;
	}//fecha removeFuncionario
	
	/**
	 * Metodo que busca funcionario no banco
	 * @param Matricula - matricula do funcionario
	 * @return retorna true para funcionario achado ou false para nao achado
	 */
	public boolean buscaFuncionario(String matricula){
		return equipeFuncionarios.containsKey(matricula);
	}//fecha buscaFuncionario
	
	/**
	 * Metodo que pega um funcionario do banco
	 * @param matricula - matricula do funcionario
	 * @return - retorna um funcionario ou lanca uma exception
	 */
	public Funcionario getFuncionario(String matricula) throws FuncionarioInvalidoException{
		
		if(buscaFuncionario(matricula)){
			return equipeFuncionarios.get(matricula);
		}//fecha if
		throw new FuncionarioInvalidoException("Funcionario nao existe");
	}//fecha getFuncionario
	
	/**
	 * Metodo que retorna a quantidade atual de funcionarios cadastrados no sistema
	 * @return retorna um valor referente a quantidade de funcionarios cadastrados atualmente no sistema
	 */
	public int getQuantidadeDeFuncionarios(){
		return equipeFuncionarios.size();
	}//fecha getQuantidadeDeFuncionarios
	
}//fecha class
