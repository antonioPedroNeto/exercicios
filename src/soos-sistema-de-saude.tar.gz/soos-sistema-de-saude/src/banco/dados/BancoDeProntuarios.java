package banco.dados;

import java.util.ArrayList;
import java.util.List;

import pacientes.protuario.Prontuario;

/**
 * 
 * @author LUIZ FERNANDO DA SILVA
 *
 */
public class BancoDeProntuarios {

	private List<Prontuario> prontuarios;

	public BancoDeProntuarios() {

		prontuarios = new ArrayList<Prontuario>();
	}

	/**
	 * Esse metodo adicina um protuario a lista de prontuarios
	 * 
	 * @param prontuario - recebe o prontuario a ser adicionado
	 * @return - retorna um boolean indicando se o prontuario foi adicionado ou nao
	 */
	public boolean adicionaProtuario(Prontuario prontuario){

		if(! containUsuario(prontuario)){
			return prontuarios.add(prontuario);

		}else return false;
	}

	/**
	 * Esse metodo verifica se um protntuario existe na lista de prontuarios
	 * 
	 * @param prontuario - recebe um protuario que sera comparado
	 * @return - retorna um boolean indicando se o prontuario existe ou nao
	 */
	private boolean containUsuario(Prontuario prontuario){
		return prontuarios.contains(prontuario);
	}

	/**
	 * Esse metodo verifica se um protntuario existe na lista de prontuarios
	 * 
	 * @param nomePaciente - recebe o nome do paciente que sera procurado
	 * @return - retorna um boolean indicando se o prontuario existe ou nao
	 */
	public boolean containProntuario(String nomePaciente){

		for(Prontuario prontuario : this.prontuarios){

			if(prontuario.getNome().equalsIgnoreCase(nomePaciente)){
				return true;
			}
		}

		return false;
	}

	public Prontuario getProntuario(String nomePaciente)throws Exception{

		if(containProntuario(nomePaciente)){

			for(Prontuario prontuario : this.prontuarios){

				if(prontuario.getNome().equalsIgnoreCase(nomePaciente)){
					return prontuario;

				}
			}	
		
		}
			
		throw new Exception("Prontuario nao existe");
	}

}
