package pacientes.paciente;

import java.time.LocalDate;

import enumeration.TipoSanguineo;


/**
 * 
 * Classe que representa um paciente
 * 
 * @author Luiz Fernando, Antonio Pedro, Davi Laerte
 *
 */
public class Paciente {
	
	private String nome;
	private LocalDate dataNascimento;
	private double peso;
	private final String sexoBiologico;
	private final String genero;
	private final TipoSanguineo tipoSanguineo;
	private int id;
	
	public Paciente(String nome, LocalDate dataNascimento, double peso, String sexoBiologico, String genero, TipoSanguineo tipoSanguineo, int id) {
		
		this.nome = nome;
		this.dataNascimento = dataNascimento;
		this.peso = peso;
		this.sexoBiologico = sexoBiologico;
		this.genero = genero;
		this.tipoSanguineo = tipoSanguineo;
		
		
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public LocalDate getDataNascimento() {
		return dataNascimento;
	}

	public String getSexoBiologico() {
		return sexoBiologico;
	}

	public String getGenero() {
		return genero;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Paciente other = (Paciente) obj;
		if (id != other.id)
			return false;
		return true;
	}

	
	
}
