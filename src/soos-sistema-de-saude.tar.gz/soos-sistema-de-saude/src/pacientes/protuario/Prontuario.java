package pacientes.protuario;

import java.time.LocalDate;
import java.util.UUID;

import pacientes.paciente.Paciente;

public class Prontuario implements Comparable<Paciente>{
	
	private Paciente paciente;

	//algum conjunto de procedimentos
	
	
	public Prontuario(Paciente paciente){
		this.paciente = paciente;
	}
	
	
	
	@Override
	public int compareTo(Paciente outroPaciente) {
		
		return paciente.getNome().compareTo(outroPaciente.getNome());
		
	}



	public String getNome() {
		return paciente.getNome();
	}



	public double getPeso() {
		return paciente.getPeso();
	}



	public LocalDate getDataNascimento() {
		return paciente.getDataNascimento();
	}



	public String getSexoBiologico() {
		return paciente.getSexoBiologico();
	}



	public String getGenero() {
		return paciente.getGenero();
	}


/*
	public UUID getId() {
		return paciente.getId();
	}*/



	public void setNome(String nome) {
		paciente.setNome(nome);
	}



	public void setPeso(double peso) {
		paciente.setPeso(peso);
	}
	
	
}
