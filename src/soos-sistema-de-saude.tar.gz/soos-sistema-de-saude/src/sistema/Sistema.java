package sistema;

import java.time.LocalDate;

import banco.dados.*;
import exceptions.ChaveInvalidaException;
import exceptions.FuncionarioInvalidoException;
import exceptions.StatusDeSistemaException;
import exceptions.SoosException;
import exceptions.StringInvalidaException;
import factorys.FactoryDeFuncionarios;
import funcionario.Funcionario;
import sistema.controller.ControllerAcessos;
import enumeration.Cargo;
/**
 * 
 * @author Lucas Silva, Antonio Pedro
 *  
 */
public class Sistema {
	//FACADE
	
}
