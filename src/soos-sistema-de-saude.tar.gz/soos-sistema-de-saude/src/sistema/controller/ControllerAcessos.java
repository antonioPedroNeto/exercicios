package sistema.controller;

import java.time.LocalDate;
import java.time.Month;

import acoes.AcaoDiretor;
import acoes.AcaoMedicos;
import acoes.AcoesFuncionarios;
import banco.dados.BancoDeFuncionarios;
import banco.dados.BancoDeProntuarios;
import enumeration.Acao;
import enumeration.Cargo;
import exceptions.ChaveInvalidaException;
import exceptions.FuncionarioInvalidoException;
import exceptions.PermissaoInsuficienteException;
import exceptions.SenhaInvalidaException;
import exceptions.SoosException;
import exceptions.StatusDeSistemaException;
import exceptions.StringInvalidaException;
import factorys.FactoryDeFuncionarios;
import funcionario.Funcionario;
import sistema.controller.permissoes.GerenciadorPermissoes;

/**
 * 
 * @author Lucas Silva
 *
 */
public class ControllerAcessos {
	private static final String CHAVE_ACESSO = "c041ebf8";
	
	private FactoryDeFuncionarios factoryFuncionarios;
	private BancoDeFuncionarios bancoDeFuncionarios;
	private BancoDeProntuarios bancoDeProntuarios;
	private Funcionario funcionarioLogado;
	private GerenciadorPermissoes permissoes;
	private boolean sistemaLiberado;
	private AcoesFuncionarios acoesFuncionarios;
	
	public ControllerAcessos(){
		bancoDeFuncionarios = new BancoDeFuncionarios();
		bancoDeProntuarios = new BancoDeProntuarios();
		factoryFuncionarios = new FactoryDeFuncionarios();
		permissoes = new GerenciadorPermissoes();
		sistemaLiberado = false;
		funcionarioLogado = factoryFuncionarios.criaFuncionario("bartolomeu", Cargo.MEDICO, LocalDate.of(1996, Month.SEPTEMBER, 03));
		
		if(funcionarioLogado.getCargo()==Cargo.DIRETOR_GERAL){
			acoesFuncionarios = new AcaoDiretor();
		}else if(funcionarioLogado.getCargo()==Cargo.MEDICO){
			acoesFuncionarios = new AcaoMedicos();
		}
		
	}
	/**
	 * Metodo que libera o sistema para o uso
	 * @param chave - chave para liberar o sistema
	 * @return retorna um boolean true para liberado ou false para nao liberado
	 * @throws ChaveInvalidaException, StringInvalidaException - pode lancar uma exception caso a chave seja invalida
	 */
	public String liberaSistema(String chave) throws StringInvalidaException, StatusDeSistemaException{
		verificaChave(chave);
		verificaSistemaJaLiberado();
		
		if(chave.equals(CHAVE_ACESSO)){
			sistemaLiberado = true;
		}else{
			throw new ChaveInvalidaException();
		}
		
		Funcionario funcionario = factoryFuncionarios.criaFuncionario("Diretor", Cargo.DIRETOR_GERAL, LocalDate.now());
		bancoDeFuncionarios.adicionaFuncionario(funcionario);
		
		return funcionario.getMatricula();
	}
	
	/**
	 * Metodo que realiza o login do funcionario
	 * @param matricula - matricula do funcionario
	 * @param senha - senha do funcionario
	 * @return - retorna um boolean true para logado com sucesso ou false para nao logado
	 * @throws SoosException 
	 * @throws Exception
	 */
	public boolean realizaLogin(String matricula, String senha) throws SoosException {
		verificaSistemaBloqueado();
		verificaSistemaJaLogado();
		verificaMatricula(matricula);
		verificaSenha(senha);
		verificaUsuarioCadastrado(matricula);
		
		Funcionario funcionario = bancoDeFuncionarios.getFuncionario(matricula);
		
		return autenticaFuncionario(funcionario, senha);
	}
	
	public boolean deslogar(){
		if(funcionarioLogado==null){
			return false;
		}
		
		funcionarioLogado = null;
		return true;
	}
	
	public boolean estaLogado(){
		if(funcionarioLogado==null){
			return false;
		}
		return true;
	}
	
	public boolean cadastraFuncionario(String nome, Cargo cargo, LocalDate dataNascimento) throws Exception {
		/*verificaSistemaBloqueado();
		verificaUsuarioLogado();*/
		
		Funcionario funcionario = acoesFuncionarios.cadastraFuncionario(nome, cargo, dataNascimento);
		
		return bancoDeFuncionarios.adicionaFuncionario(funcionario);
	}
	public boolean removeFuncionario(String matricula) {
		return bancoDeFuncionarios.removeFuncionario(matricula);
	}

	public boolean buscaFuncionario(String matricula) {
		return bancoDeFuncionarios.buscaFuncionario(matricula);
	}

	public Funcionario getFuncionario(String matricula) throws FuncionarioInvalidoException {
		return bancoDeFuncionarios.getFuncionario(matricula);
	}

	public int getQuantidadeDeFuncionarios() {
		return bancoDeFuncionarios.getQuantidadeDeFuncionarios();
	}

	/**
	 * @return Retorna um boolean true se o sistema estiver liberado ou false 
	 * caso nao esteja.
	 */
	public boolean estaLiberado(){
		return sistemaLiberado;
	}
	
	private void verificaUsuarioLogado() throws StatusDeSistemaException {
		if(!estaLogado()){
			throw new StatusDeSistemaException("O sistema nao tem um usuario logado.");
		}
	}
	/**
	 * Metodo que verifica se a senha informada corresponde a senha do usuario
	 * @param senha - possivel senha do usuario
	 * @param funcionario - o funcionario
	 * @throws StringInvalidaException
	 */
	private void verificaSenha(Funcionario funcionario, String senha) throws StringInvalidaException {
		if(senha == null || senha.isEmpty()){
			throw new StringInvalidaException("A senha nao pode ser null ou vazio.");
		}
		
		if(!funcionario.autentica(senha)){
			throw new SenhaInvalidaException();
		}
	}
	/**
	 * Metodo que verifica se o funcionario esta cadastrado no sistema
	 * @param matricula - matricula do funcionario
	 * @throws FuncionarioInvalidoException - caso o funcionario nao esteja cadastrado.
	 */
	private void verificaUsuarioCadastrado(String matricula) throws FuncionarioInvalidoException {
		if(!bancoDeFuncionarios.buscaFuncionario(matricula)){
			throw new FuncionarioInvalidoException("O funcionario nao esta cadastrado no sistema.");
		}
	}
	private boolean autenticaFuncionario(Funcionario funcionario, String senha) throws StringInvalidaException{
		verificaSenha(funcionario, senha);
		
		funcionarioLogado = funcionario;
		return true;
	}
	private void verificaMatricula(String matricula) throws StringInvalidaException {
		if(matricula == null || matricula.isEmpty()){
			throw new StringInvalidaException("A matricula nao pode ser nula ou vazia.");
		}
		
	}
	private void verificaChave(String chave) throws StringInvalidaException {
		if(chave == null || chave.isEmpty()){
			throw new StringInvalidaException("A chave nao pode ser nula ou vazia.");
		}
	}
	
	private void verificaSenha(String senha) throws StringInvalidaException {
		if(senha == null || senha.isEmpty()){
			throw new StringInvalidaException("A senha nao pode ser nula ou vazia.");
		}
	}

	/**
	 * Metodo que verifica se o sistema esta liberado.
	 * @throws StatusDeSistemaException - caso ja esteja liberado.
	 */
	private void verificaSistemaJaLiberado() throws StatusDeSistemaException {
		if(sistemaLiberado){
			throw new StatusDeSistemaException("O sistema ja esta liberado.");
		}
	}

	
	/**
	 * Metodo que verifica se o sistema ja tem um funcionario logado.
	 * @throws SoosException - caso ja tenha um funcionario logado.
	 */
	private void verificaSistemaJaLogado() throws SoosException {
		if(estaLogado()){
			throw new SoosException("O sistema ja tem um funcionario logado.");
		}
	}
	
	/**
	 * Metodo que verifica se o sistema esta bloqueado.
	 * @throws StatusDeSistemaException - caso esteja bloqueado.
	 */
	private void verificaSistemaBloqueado() throws StatusDeSistemaException{
		if(!sistemaLiberado){
			throw new StatusDeSistemaException("O sistema esta bloqueado.");
		}
	}
	
	public boolean alteraSenha(Funcionario funcionario, String senhaAntiga, String senhaNova) throws SenhaInvalidaException{
		
	}
	
}
