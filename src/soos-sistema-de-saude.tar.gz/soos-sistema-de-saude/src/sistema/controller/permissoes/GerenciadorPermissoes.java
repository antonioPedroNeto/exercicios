package sistema.controller.permissoes;

import enumeration.Cargo;
import exceptions.PermissaoInsuficienteException;
import funcionario.Funcionario;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import enumeration.Acao;

/**
 * 
 * @author Lucas Silva
 *
 */
public class GerenciadorPermissoes {
	private Map<Cargo,Set<Acao>> permissoes;
	
	private Set<Acao> permissoesDiretor;
	private Set<Acao> permissoesMedico;
	private Set<Acao> permissoesTecnico;
	
	public GerenciadorPermissoes(){
		permissoes = new HashMap<Cargo, Set<Acao>>();
		
		permissoesDiretor = new HashSet<Acao>();
		permissoesMedico = new HashSet<Acao>();
		permissoesTecnico = new HashSet<Acao>();
		
		// permissoes do tecnico administrativo
		permissoesTecnico.add(Acao.CADASTRAR_USUARIO);
		
		// permissoes do medico
		//aqui
		
		// permissoes do diretor (todas as acoes do sistema)
		permissoesDiretor.addAll(permissoesMedico);
		permissoesDiretor.addAll(permissoesTecnico);
		
		
		permissoes.put(Cargo.DIRETOR_GERAL, permissoesDiretor);
		permissoes.put(Cargo.MEDICO, permissoesMedico);
		permissoes.put(Cargo.TECNICO_ADMINISTRATIVO, permissoesTecnico);
	}
	
	/**
	 * Metodo responsavel por verificar se o funcionario logado tem acesso a determinada acao.
	 * @param funcionarioLogado
	 * @param acao
	 * @throws PermissaoInsuficienteException - caso nao tenha acesso.
	 */
	public void validar(Funcionario funcionarioLogado, Acao acao) throws PermissaoInsuficienteException{
		Set<Acao> acoesPermitidas = permissoes.get(funcionarioLogado.getCargo());
		
		if(!acoesPermitidas.contains(acao)){
			throw new PermissaoInsuficienteException();
		}
	}
}
