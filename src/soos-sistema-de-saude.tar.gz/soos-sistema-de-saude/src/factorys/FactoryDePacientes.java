package factorys;

import java.time.LocalDate;
import java.util.UUID;

import enumeration.TipoSanguineo;
import pacientes.paciente.Paciente;

public class FactoryDePacientes {

	private int quantidadeCadastros; //sera mudado para UUID	
	
	public FactoryDePacientes(){
		this.quantidadeCadastros = 0;
	}
	
	public Paciente cadastraPaciente(String nome, LocalDate dataNascimento, double peso, String sexoBiologico, 
			String genero, TipoSanguineo tipoSanguineo){
		this.quantidadeCadastros += 1;
		return new Paciente(nome, dataNascimento, peso, sexoBiologico, genero, tipoSanguineo, quantidadeCadastros);
	}
	
	
	
}
