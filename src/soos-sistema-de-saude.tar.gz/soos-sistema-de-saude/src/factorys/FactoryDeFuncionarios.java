package factorys;

import java.time.LocalDate;

import enumeration.Cargo;
import funcionario.Funcionario;

public class FactoryDeFuncionarios {

	private int quantidadeCadastros; //sera mudado para UUID
	
	private int anoAtual; //sera mudado para um metodo que retorna o ano atual
	
	public FactoryDeFuncionarios(){
		this.anoAtual = LocalDate.now().getYear();
		this.quantidadeCadastros = 1;
	}
	
	/**
	 * Metodo que cria uma funcionario
	 * @param nome - Nome do funcionario
	 * @param matricula - Matricula do funcionario
	 * @param senha - senha do funcionario
	 * @param cargo - cargo do funcionario
	 * @param dataNascimento - data de nascimento do funcionario
	 * @return retorna um novo funcionario
	 */
	public Funcionario criaFuncionario(String nome, Cargo cargo, LocalDate dataNascimento){
		String matricula = geraMatricula(cargo, anoAtual);//pega a matricula
		String senha = geraSenha(matricula, dataNascimento);//pega a senha
		quantidadeCadastros += 1;
		return new Funcionario(nome, matricula, senha, cargo, dataNascimento);//cria e retorna um novo funcionario
	}//fecha criaFuncionario
	
	

	/**
	 * Metodo que gera a senha do funcionario
	 * @param matricula - matricula do funcionario
	 * @param dataNascimento - data de nascimento do funcionario
	 * @param quantidadeCadastros - quantidade de usuarios cadastrados
	 * @return retorna uma senha
	 */
	private String geraSenha(String matricula, LocalDate dataNascimento){
		
		String senha = String.valueOf(dataNascimento.getYear());//pega o ano de nascimento
		
		senha += matricula.substring(0, 4);//pega os 4 primeiros digitos da matricula

		return senha;//retorna a senha gerada
		
	}//fecha geraSenha
	

	/**
	 * Metodo que gera a matricula do funcionario
	 * @param cargo - cargo do funcionario
	 * @param anoAtual - ano atual
	 * @param quantidadeCadastros quantidade de usuarios cadastrados
	 * @return retorna uma matricula
	 */
	private String geraMatricula(Cargo cargo, int anoAtual){
		String prefixo;
		
		if(cargo == Cargo.DIRETOR_GERAL){
			prefixo = "1";
		}else if(cargo == Cargo.MEDICO){
			prefixo = "2";
		}else{//(cargo == Cargo.TECNICO_ADMINISTRATRIVO)
			prefixo = "3";
		}//fecha else
		
		return prefixo+anoAtual+String.format("%03d", quantidadeCadastros);
	}//fecha geraMatricula
	
}//fecha class