package factorys;

import java.time.LocalDate;
import java.util.UUID;

import pacientes.paciente.Paciente;

/**
 * Classe factory de pacientes - cria pacientes.
 * 
 * @author davi laerte
 *
 */
public class FactoryProntuario {

	/**
	 * metodo que cria novo paciente.
	 * 
	 * @param nome
	 *            <String> - nome do paciente.
	 * @param dataNascimento
	 *            <LocalDate> data Nascimento do paciente.
	 * @param peso
	 *            <double> - peso do paciente.
	 * @param sexoBiologico
	 *            <String> - sexo biologico do paciente.
	 * @param genero
	 *            <String> - genero do paciente.
	 * @param id
	 *            <UUID> - id que representa o paciente.
	 * @return <Paciente> - paciente criado.
	 */
/*	public Paciente criaPacienteString nome, LocalDate dataNascimento, double peso, String sexoBiologico,
			String genero, UUID id) {
		Paciente paciente = new Paciente(nome, dataNascimento, peso, sexoBiologico, genero, id);

		return paciente;
	}*/

}// fim classe.
