package enumeration;

public enum Acao {
	CADASTRAR_USUARIO
}
