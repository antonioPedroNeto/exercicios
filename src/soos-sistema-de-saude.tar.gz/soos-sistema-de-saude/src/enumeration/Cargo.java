package enumeration;

public enum Cargo {
	
	DIRETOR_GERAL, MEDICO, TECNICO_ADMINISTRATIVO
}
