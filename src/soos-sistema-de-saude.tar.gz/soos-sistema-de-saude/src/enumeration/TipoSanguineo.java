package enumeration;

public enum TipoSanguineo {

	/**
	 * AP = A+
	 * BP = B+
	 * ABP = AB+
	 * OP = O+
	 * AN = A-
	 * BN = B-
	 * ABN = AB-
	 * ON = O-
	 */
	
	AP, BP, ABP, OP, AN, BN, ABN, ON
	
}
