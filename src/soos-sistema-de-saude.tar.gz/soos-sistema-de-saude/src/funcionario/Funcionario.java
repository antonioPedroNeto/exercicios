package funcionario;

import java.time.LocalDate;

import enumeration.Cargo;
import exceptions.SenhaInvalidaException;

/**
 * 
 * @author LUIZ FERNANDO DA SILVA, ANTONIO PEDRO DE ABREU NETO
 *
 */
public class Funcionario {
	
	private String matricula;
	private String nome;
	private String senha;
	private Cargo cargo;
	private LocalDate dataNascimento;
	
	/**
	 * Contrutor da classe Funcionarios
	 * 
	 * @param nome - recebe o nome do funcinario
	 * @param matricula - recebe a matricula do funcionario
	 * @param senha - recebe a senha do funcionario
	 * @param cargo - recebe o cargo do usuario
	 * @param dataNascimento - recebe a data de nascimento
	 */
	public Funcionario(String nome, String matricula,String senha, Cargo cargo, LocalDate dataNascimento) {
		
		this.nome = nome;
		this.matricula = matricula;
		this.cargo = cargo;
		this.senha = senha;
		this.dataNascimento = dataNascimento;
	}

	/**
	 * Verifica se a senha passada e igual a senha atual
	 * @param senha - uma senha
	 * @return retorna true para e igual a senha atual ou false para nao e igual
	 */
	public boolean autentica(String senha){
		return this.senha.equals(senha);
	}
	/**
	 * Esse funcao retorna a matricula do usuario
	 * 
	 * @return retorna uma string indicando a matricula do usuario
	 */
	public String getMatricula() {
		return matricula;
	}

	/**
	 * Esse metodo troca a matricula do usuario
	 * 
	 * @param matricula - recebe a nova matricula do funcionario
	 */
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	/**
	 * Esse metodo retorna o nome do funcionario
	 * 
	 * @return - retorna uma string indicando o nome do funcionario
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * Esse metodo altera o nome do funcionario
	 * 
	 * @param nome - recebe o novo nome do funcionario
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	 * Esse metodo altera a senha do funcionario
	 * 
	 * @param senhaAtual - recebe a senha atual do funcionario
	 * @param novaSenha - recebe a nova senha do funcionario
	 * @throws SenhaInvalidaException - gera uma senha caso a senha passada seja invalida
	 */
	public boolean setSenha(String senhaAtual, String novaSenha) throws SenhaInvalidaException{
		
		if(autentica(novaSenha)){
			this.senha = novaSenha;
			return true;
			
		}else throw new SenhaInvalidaException("Senha não correspondente");
	}

	/**
	 * Esse metodo retorna o cargo do usuario
	 * 
	 * @return - retorna um enumeration informando o cargo do funcionario
	 */
	public Cargo getCargo() {
		return cargo;
	}

	/**
	 * Esse metodo altera o cargo do funcionario
	 * 
	 * @param cargo - recebe o novo cargo
	 */
	public void setCargo(Cargo cargo) {
		this.cargo = cargo;
	}

	/**
	 * Esse metodo retorna a data de nascimento do usuario
	 * 
	 * @return retorna um objeto do tipo LocalDate contendo a data de nascimento
	 */
	public LocalDate getDataNascimento() {
		return dataNascimento;
	}
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((matricula == null) ? 0 : matricula.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		
		if(obj instanceof Funcionario){
			
			Funcionario outroFuncionario = (Funcionario) obj;
			
			return (outroFuncionario.getMatricula().equalsIgnoreCase(this.getMatricula()));
		}
		
		return false;
	}
	
	
}
